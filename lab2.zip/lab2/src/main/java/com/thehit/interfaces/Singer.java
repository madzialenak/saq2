package com.thehit.interfaces;

import com.thehit.domain.Song;

public interface Singer {

	void perform (Song song);
	
}
