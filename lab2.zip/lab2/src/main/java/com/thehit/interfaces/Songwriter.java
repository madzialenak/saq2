package com.thehit.interfaces;

import com.thehit.domain.Song;

public interface Songwriter {

	void compose(Song song);
	
}
