package com.thehit.domain;

public class SongWriterImpl {
	
	private String firstname;
	private String lastname;
	private int age;
	private Song song;
	
	public SongWriterImpl (String firstname, String lastname, int age, String Song) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.age = age;
		this.song = song;
	
	}

	public SongWriterImpl() {
		System.out.println("We are here in the default constructor");
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Song getSong() {
		return song;
	}

	public void setSong(Song song) {
		this.song = song;
	}

	public void Compose() {
		System.out.println("Composer " + firstname + " " + lastname + " composed a song called " + song.getName() + ". This song has the following lyrics " + song.getLyrics());
	}
	
	
}
